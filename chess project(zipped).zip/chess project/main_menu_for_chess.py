import pygame as p
import pygame_gui
import chessmain
import chessmaincomp
import chessmain960
import chessmain960comp

# Initialize pygame and pygame_gui
p.init()

# Create a resizable window
screen = p.display.set_mode((512, 512), p.RESIZABLE)  
p.display.set_caption("Chess Game - Main Menu")


# Load the image for the icon (should be small, e.g., 32x32 px for best results)
icon = p.image.load(r"pieces/chancellor.webp")

# Set the loaded image as the window icon
p.display.set_icon(icon)

# Set up the pygame_gui manager
manager = pygame_gui.UIManager((512, 512))

# Load and scale the background image initially
# background = p.image.load(r'background/background8.jpg')
# background = p.transform.scale(background, (512, 512))
background = p.image.load("background/background1.webp").convert()
background = p.transform.smoothscale(background, (512, 512))


# Create buttons for different game modes
btn_pvp = pygame_gui.elements.UIButton(
    relative_rect=p.Rect((100, 100), (300, 50)),
    text='Player vs Player',
    manager=manager
)

btn_pvai = pygame_gui.elements.UIButton(
    relative_rect=p.Rect((100, 170), (300, 50)),
    text='Player vs Comp',
    manager=manager
)

btn_aivai = pygame_gui.elements.UIButton(
    relative_rect=p.Rect((100, 240), (300, 50)),
    text='Chess960',
    manager=manager
)

btn_timed = pygame_gui.elements.UIButton(
    relative_rect=p.Rect((100, 310), (300, 50)),
    text='Chess960 vs Comp',
    manager=manager
)

# Clock to control the frame rate
clock = p.time.Clock()
running = True

while running:
    # Calculate time delta for smooth animations
    time_delta = clock.tick(60) / 1000.0

    # Handle events
    for event in p.event.get():
        if event.type == p.QUIT:
            running = False

        # Adjust layout on window resize
        elif event.type == p.VIDEORESIZE:
            screen = p.display.set_mode((event.w, event.h), p.RESIZABLE)
            manager.set_window_resolution((event.w, event.h))
            background = p.transform.scale(background, (event.w, event.h))

        if event.type == pygame_gui.UI_BUTTON_PRESSED:
            if event.ui_element == btn_pvp:
                chessmain.main()  # Launch Player vs Player mode
            elif event.ui_element == btn_pvai:
                chessmaincomp.main()
                print("Player vs Computer mode selected")
                # Add corresponding function for this mode
            elif event.ui_element == btn_aivai:
                chessmain960.main()
                print("Chess960 mode selected")
                # Add corresponding function for this mode
            elif event.ui_element == btn_timed:
                chessmain960comp.main()
                print("Chess960 vs Computer selected")
                # Add corresponding function for this mode



        # Process pygame_gui events
        manager.process_events(event)

    # Update the GUI manager
    manager.update(time_delta)

    # Draw the background image
    screen.blit(background, (0, 0))

    # Draw the GUI elements on top of the background
    manager.draw_ui(screen)

    # Update the display
    p.display.flip()

# Quit pygame
p.quit()
