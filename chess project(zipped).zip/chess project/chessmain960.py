import pygame as p
import chessengine960
BOARD_WIDTH=512
BOARD_HEIGHT=512
DIMENSION=8
WIDTH=512
SQ_SIZE=BOARD_HEIGHT//DIMENSION
MOVE_LOG_PANEL_WIDTH =250
MOVE_LOG_PANEL_HEIGHT= BOARD_HEIGHT
MAX_FPS=15
IMAGES={}
def loadImages():
    pieces=['wp','wR','wN','wB','wK','wQ','bp','bR','bN','bB','bK','bQ']
    for piece in pieces:
        IMAGES[piece]=p.transform.scale(p.image.load("pieces/"+piece+".png"),(SQ_SIZE, SQ_SIZE))
def setIcon():
    """Sets the game window icon to a knight symbol."""
    icon = p.image.load("pieces/bK.png")  # Load your knight symbol here
    p.display.set_icon(icon)
def main():
    p.init()
    setIcon()  # Set the icon when initializing the game
    screen=p.display.set_mode((BOARD_WIDTH + MOVE_LOG_PANEL_WIDTH,BOARD_HEIGHT))
    p.display.set_caption("Crown's Last Stand")
    clock=p.time.Clock()
    screen.fill(p.Color("white"))
    moveLogFont=p.font.SysFont("Arial", 12, False, False)
    gs=chessengine960.GameState()
    validMove=gs.getValidMoves()
    moveMade= False
    animate = False
    loadImages()
    running =True
    sqSelected=()
    playerClicks=[]
    gameOver= False
    while running:
        for e in p.event.get():
            if e.type == p.QUIT:
                running = False
            elif e.type== p.MOUSEBUTTONDOWN:
                if not gameOver:
                    location=p.mouse.get_pos()
                    col = location[0]//SQ_SIZE
                    row=location[1]//SQ_SIZE
                    if sqSelected==(row,col) or col>= 8:
                        sqSelected=()
                        playerClicks=[]
                    else:
                        sqSelected=(row,col)
                        playerClicks.append(sqSelected)
                    if len(playerClicks)==2:
                        move = chessengine960.Move(playerClicks[0], playerClicks[1],gs.board)
                        print(move.getChessNotation())
                        if move in validMove:
                            gs.makeMove(move)
                            moveMade= True
                        sqSelected=()
                        playerClicks=[]
            elif e.type == p.KEYDOWN:
                if e.key == p.K_z and len(gs.movelog) > 0:
                    gs.undoMove()
                    moveMade = True
                    animate = False
                    gameOver = False  # Clear any game over state after undo

                if e.key == p.K_RETURN:  # Reset with the Enter key
                    gs = chessengine960.GameState()
                    validMove = gs.getValidMoves()
                    sqSelected = ()
                    playerClicks = []
                    moveMade = False
                    animate = False
                    gameOver = False
                    winner = None  # Clear any previous winner

                if e.key == p.K_r and not gameOver:  # Resignation
                    gameOver = True
                    winner = "Black" if gs.whiteToMove else "White"
                    drawEndGameText(screen, "Black won by resignation") if winner =="Black" else drawEndGameText(screen, "White won by resignation")
                    resignationMessage = f"{winner} won by resignation"
        if moveMade:
            if animate:
                animateMove(gs.movelog[-1], screen, gs.board, clock)
            validMove=gs.getValidMoves()
            moveMade= False
        drawGameState(screen,gs, validMove, sqSelected, moveLogFont)
        if gameOver==True:
            drawEndGameText(screen, resignationMessage)
        clock.tick(MAX_FPS)
        p.display.flip()

def highlightSquares(screen, gs, validMove, sqSelected):
    if sqSelected !=():
        r, c =sqSelected
        if gs.board[r][c][0]==('w' if gs.whiteToMove else 'b'):
            #highlight selected square
            s=p.Surface((SQ_SIZE, SQ_SIZE))
            s.set_alpha(100) #transparency
            s.fill(p.Color('blue'))
            screen.blit(s, (c*SQ_SIZE, r*SQ_SIZE))
            #highlight moves from that square
            s.fill(p.Color('yellow'))
            for move in validMove:
                if move.startRow == r and move.startCol==c:
                    screen.blit(s, (move.endCol*SQ_SIZE, move.endRow*SQ_SIZE))



def drawGameState(screen,gs, validMove, sqSelected, moveLogFont):
    drawBoard(screen)
    highlightSquares(screen, gs, validMove, sqSelected)
    drawPieces(screen, gs.board)
    drawMoveLog(screen, gs, moveLogFont)
    if gs.checkmate:
        gameOver=True
        if gs.whiteToMove:
            drawEndGameText(screen,'Black wins by checkmate')
        else:
            drawEndGameText(screen,'White wins by checkmate')
    elif gs.stalemate:
        gameOver=True
        drawEndGameText(screen, 'Stalemate')

def drawBoard(screen):
    global colors
    colors=[p.Color("light gray"),p.Color("dark gray")]
    for r in range(DIMENSION):
        for c in range(DIMENSION):
            color=colors[((r+c)%2)]
            p.draw.rect(screen, color, p.Rect(c*SQ_SIZE, r*SQ_SIZE, SQ_SIZE, SQ_SIZE))

def drawPieces(screen,board):
    for r in range(DIMENSION):
        for c in range(DIMENSION):
            piece=board[r][c]
            if piece != "--":
                screen.blit(IMAGES[piece],p.Rect(c*SQ_SIZE, r*SQ_SIZE,SQ_SIZE, SQ_SIZE))

def drawMoveLog(screen, gs, font):
    moveLogRect = p.Rect(BOARD_WIDTH, 0, MOVE_LOG_PANEL_WIDTH, MOVE_LOG_PANEL_HEIGHT)
    p.draw.rect(screen, p.Color("black"), moveLogRect)

    moveLog = gs.movelog
    moveTexts = []

    # Create move strings (white + black on one line)
    for i in range(0, len(moveLog), 2):
        moveString = str(i // 2 + 1) + ". " + moveLog[i].getChessNotation() + " "
        if i + 1 < len(moveLog):  # Check if black made a move
            moveString += moveLog[i + 1].getChessNotation()
        moveTexts.append(moveString)

    movePerRow = 3  # Number of concatenated moves per row
    padding = 5
    lineSpacing = 2
    textY = padding

    # Render and display the moves in rows
    for i in range(0, len(moveTexts), movePerRow):
        text = "   ".join(moveTexts[i:i + movePerRow])  # Join moves with spacing
        textObject = font.render(text, True, p.Color('white'))
        textLocation = moveLogRect.move(padding, textY)
        screen.blit(textObject, textLocation)
        textY += textObject.get_height() + lineSpacing  # Update Y position for next row

# def drawMoveLog(screen, gs, font):
#     moveLogRect = p.Rect(BOARD_WIDTH, 0, MOVE_LOG_PANEL_WIDTH, MOVE_LOG_PANEL_HEIGHT)
#     p.draw.rect(screen, p.Color("black"), moveLogRect)

#     moveLog = gs.movelog
#     moveTexts = [move.getChessNotation() for move in moveLog]  # Convert moves to text
#     padding = 5
#     lineSpacing = 2
#     textY = padding  # Initialize textY to start from the top with padding

#     for text in moveTexts:
#         textObject = font.render(text, True, p.Color('white'))
#         textLocation = moveLogRect.move(padding, textY)
#         screen.blit(textObject, textLocation)
#         textY += textObject.get_height() + lineSpacing  # Move down for the next text

    


#animating a move
def animateMove(move, screen, board, clock):
    global colors
    coords=[]
    dR =move.endRow - move.startRow
    dC = move.endCol - move.startCol
    framesPerSquare=10 #for one square
    frameCount = (abs(dR) + abs(dC))* framesPerSquare
    for frame in range(frameCount+1):
        r,c =(move.startRow + dR*frame/frameCount, move.startCol + dC*frame/frameCount)
        drawBoard(screen)
        drawPieces(screen, board)
        #erase the piece moved from its ending square
        color=colors[(move.endRow + move.endCol)%2]
        endSquare = p.Rect(move.endCol*SQ_SIZE, move.endRow*SQ_SIZE, SQ_SIZE, SQ_SIZE)
        p.draw.rect(screen, color, endSquare)
        #drawing captured piece onto rectangel
        if move.pieceCaptured !='--':
            screen.blit(IMAGES[move.pieceCaptured], endSquare)
        #draw moving piece
        screen.blit(IMAGES[move.pieceMoved], p.Rect(c*SQ_SIZE, r*SQ_SIZE, SQ_SIZE,SQ_SIZE))
        p.display.flip()
        clock.tick(60)
def drawEndGameText(screen, text):
    font=p.font.SysFont("helvetica",32,True,False)
    textObject=font.render(text, 0, p.Color('Gray'))
    textLocation=p.Rect(0,0,BOARD_WIDTH,BOARD_HEIGHT).move(BOARD_WIDTH/2 - textObject.get_width()/2,BOARD_HEIGHT/2-textObject.get_height()/2)
    screen.blit(textObject, textLocation)
    textObject=font.render(text, 0, p.Color('Black'))
    screen.blit(textObject, textLocation.move(3,3))
if __name__=="__main__":
    main()