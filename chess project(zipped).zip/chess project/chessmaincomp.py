import pygame as p
import chessenginecomp
import SmartMoveFinder

BOARD_WIDTH = 512
BOARD_HEIGHT = 512
DIMENSION = 8
SQ_SIZE = BOARD_HEIGHT // DIMENSION
MOVE_LOG_PANEL_WIDTH = 250
MOVE_LOG_PANEL_HEIGHT = BOARD_HEIGHT
MAX_FPS = 10
IMAGES = {}

def loadImages():
    pieces = ['wp', 'wR', 'wN', 'wB', 'wK', 'wQ', 'bp', 'bR', 'bN', 'bB', 'bK', 'bQ']
    for piece in pieces:
        IMAGES[piece] = p.transform.scale(p.image.load("pieces/" + piece + ".png"), (SQ_SIZE, SQ_SIZE))

def setIcon():
    """Sets the game window icon to a knight symbol."""
    icon = p.image.load("pieces/bQ.png")
    p.display.set_icon(icon)

def main():
    p.init()
    setIcon()
    screen = p.display.set_mode((BOARD_WIDTH + MOVE_LOG_PANEL_WIDTH, BOARD_HEIGHT))
    p.display.set_caption("Monarch's Wrath")
    clock = p.time.Clock()
    screen.fill(p.Color("white"))
    moveLogFont = p.font.SysFont("Arial", 12, False, False)
    gs = chessenginecomp.GameState()
    validMove = gs.getValidMoves()
    moveMade = False
    animate = False
    loadImages()
    running = True
    sqSelected = ()
    playerClicks = []
    gameOver = False
    playerOne = True  # Human player (white)
    playerTwo = False  # Human player (black)
    winner = None  # Store winner for resignation

    while running:
        humanTurn = (gs.whiteToMove and playerOne) or (not gs.whiteToMove and playerTwo)

        for e in p.event.get():
            if e.type == p.QUIT:
                running = False

            elif e.type == p.MOUSEBUTTONDOWN:
                if not gameOver and humanTurn:
                    location = p.mouse.get_pos()
                    col = location[0] // SQ_SIZE
                    row = location[1] // SQ_SIZE
                    if sqSelected == (row, col) or col >= 8:
                        sqSelected = ()
                        playerClicks = []
                    else:
                        sqSelected = (row, col)
                        playerClicks.append(sqSelected)
                    if len(playerClicks) == 2:
                        move = chessenginecomp.Move(playerClicks[0], playerClicks[1], gs.board)
                        print(move.getChessNotation())
                        if move in validMove:
                            gs.makeMove(move)
                            moveMade = True
                        sqSelected = ()
                        playerClicks = []

            elif e.type == p.KEYDOWN:
                if e.key == p.K_z and len(gs.movelog) > 0:
                    gs.undoMove()
                    moveMade = True
                    animate = False
                    gameOver = False  # Clear any game over state after undo

                if e.key == p.K_RETURN:  # Reset with the Enter key
                    gs = chessenginecomp.GameState()
                    validMove = gs.getValidMoves()
                    sqSelected = ()
                    playerClicks = []
                    moveMade = False
                    animate = False
                    gameOver = False
                    winner = None  # Clear any previous winner

                if e.key == p.K_r and not gameOver:  # Resignation
                    gameOver = True
                    winner = "Black" if gs.whiteToMove else "White"
                    drawEndGameText(screen, "Black won by resignation") if winner =="Black" else drawEndGameText(screen, "White won by resignation")
                    resignationMessage = f"{winner} won by resignation"

        if not gameOver and not humanTurn:
            AIMove = SmartMoveFinder.findBestMove(gs, validMove)
            if AIMove is None:
                AIMove = SmartMoveFinder.findRandomMove(validMove)
            gs.makeMove(AIMove)
            moveMade = True
            animate = True

        if moveMade:
            if animate:
                animateMove(gs.movelog[-1], screen, gs.board, clock)
            validMove = gs.getValidMoves()
            moveMade = False

        drawGameState(screen, gs, validMove, sqSelected, moveLogFont, winner)
        if gameOver==True:
            drawEndGameText(screen, resignationMessage)
        clock.tick(MAX_FPS)
        p.display.flip()

def highlightSquares(screen, gs, validMove, sqSelected):
    if sqSelected != ():
        r, c = sqSelected
        if gs.board[r][c][0] == ('w' if gs.whiteToMove else 'b'):
            s = p.Surface((SQ_SIZE, SQ_SIZE))
            s.set_alpha(100)
            s.fill(p.Color('blue'))
            screen.blit(s, (c * SQ_SIZE, r * SQ_SIZE))
            s.fill(p.Color('yellow'))
            for move in validMove:
                if move.startRow == r and move.startCol == c:
                    screen.blit(s, (move.endCol * SQ_SIZE, move.endRow * SQ_SIZE))

def drawGameState(screen, gs, validMove, sqSelected, moveLogFont, winner):
    drawBoard(screen)
    highlightSquares(screen, gs, validMove, sqSelected)
    drawPieces(screen, gs.board)
    drawMoveLog(screen, gs, moveLogFont)
    # if gs.checkmate:
    #     gameOverText = 'Black wins by checkmate' if gs.whiteToMove else 'White wins by checkmate'
    #     drawEndGameText(screen, gameOverText)
    # elif gs.stalemate:
    #     drawEndGameText(screen, 'Stalemate')
    # elif winner:
    #     drawEndGameText(screen, f"{winner} wins by resignation")
    if gs.checkmate:
        gameOver = True
        if gs.whiteToMove:  # If it's still white's turn, black won in the last move
            drawEndGameText(screen, 'Black wins by checkmate')
        else:
            drawEndGameText(screen, 'White wins by checkmate')
    elif gs.stalemate:
        gameOver = True
        drawEndGameText(screen, 'Stalemate')

def drawBoard(screen):
    global colors
    colors = [p.Color("White"), p.Color("dark gray")]
    for r in range(DIMENSION):
        for c in range(DIMENSION):
            color = colors[(r + c) % 2]
            p.draw.rect(screen, color, p.Rect(c * SQ_SIZE, r * SQ_SIZE, SQ_SIZE, SQ_SIZE))

def drawPieces(screen, board):
    for r in range(DIMENSION):
        for c in range(DIMENSION):
            piece = board[r][c]
            if piece != "--":
                screen.blit(IMAGES[piece], p.Rect(c * SQ_SIZE, r * SQ_SIZE, SQ_SIZE, SQ_SIZE))

# def drawMoveLog(screen, gs, font):
#     moveLogRect = p.Rect(BOARD_WIDTH, 0, MOVE_LOG_PANEL_WIDTH, MOVE_LOG_PANEL_HEIGHT)
#     p.draw.rect(screen, p.Color("black"), moveLogRect)

#     moveTexts = [f"{i//2 + 1}. {move.getChessNotation()}" for i, move in enumerate(gs.movelog)]
#     padding, textY, lineSpacing = 5, 5, 2

#     for text in moveTexts:
#         textObject = font.render(text, True, p.Color('white'))
#         screen.blit(textObject, moveLogRect.move(padding, textY))
#         textY += textObject.get_height() + lineSpacing
def drawMoveLog(screen, gs, font):
    moveLogRect = p.Rect(BOARD_WIDTH, 0, MOVE_LOG_PANEL_WIDTH, MOVE_LOG_PANEL_HEIGHT)
    p.draw.rect(screen, p.Color("black"), moveLogRect)

    moveLog = gs.movelog
    moveTexts = []

    # Create move strings (white + black on one line)
    for i in range(0, len(moveLog), 2):
        moveString = str(i // 2 + 1) + ". " + moveLog[i].getChessNotation() + " "
        if i + 1 < len(moveLog):  # Check if black made a move
            moveString += moveLog[i + 1].getChessNotation()
        moveTexts.append(moveString)

    movePerRow = 3  # Number of concatenated moves per row
    padding = 5
    lineSpacing = 2
    textY = padding

    # Render and display the moves in rows
    for i in range(0, len(moveTexts), movePerRow):
        text = "   ".join(moveTexts[i:i + movePerRow])  # Join moves with spacing
        textObject = font.render(text, True, p.Color('white'))
        textLocation = moveLogRect.move(padding, textY)
        screen.blit(textObject, textLocation)
        textY += textObject.get_height() + lineSpacing  # Update Y position for next row

def animateMove(move, screen, board, clock):
    global colors
    dR, dC = move.endRow - move.startRow, move.endCol - move.startCol
    frameCount = (abs(dR) + abs(dC)) * 10
    for frame in range(frameCount + 1):
        r = move.startRow + dR * frame / frameCount
        c = move.startCol + dC * frame / frameCount
        drawBoard(screen)
        drawPieces(screen, board)
        color = colors[(move.endRow + move.endCol) % 2]
        p.draw.rect(screen, color, p.Rect(move.endCol * SQ_SIZE, move.endRow * SQ_SIZE, SQ_SIZE, SQ_SIZE))
        if move.pieceCaptured != '--':
            screen.blit(IMAGES[move.pieceCaptured], p.Rect(move.endCol * SQ_SIZE, move.endRow * SQ_SIZE, SQ_SIZE, SQ_SIZE))
        screen.blit(IMAGES[move.pieceMoved], p.Rect(c * SQ_SIZE, r * SQ_SIZE, SQ_SIZE, SQ_SIZE))
        p.display.flip()
        clock.tick(60)

def drawEndGameText(screen, text):
    font = p.font.SysFont("helvetica", 32, True, False)
    textObject = font.render(text, 0, p.Color('Gray'))
    textLocation = p.Rect(0, 0, BOARD_WIDTH, BOARD_HEIGHT).move(
        BOARD_WIDTH / 2 - textObject.get_width() / 2,
        BOARD_HEIGHT / 2 - textObject.get_height() / 2
    )
    screen.blit(textObject, textLocation)
    screen.blit(font.render(text, 0, p.Color('Black')), textLocation.move(3, 3))

if __name__ == "__main__":
    main()
